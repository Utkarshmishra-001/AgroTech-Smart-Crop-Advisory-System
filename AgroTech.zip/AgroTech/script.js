const BACKEND_URL = "http://localhost:8005"; // FastAPI Backend URL

const crops = [
    {
        id: 1,
        name: "Rice",
        summary: "The staple food of millions, requiring high humidity and rainfall.",
        image: "https://www.gffoodservice.com.au/wp-content/uploads/2019/12/lomg-grain@1x.jpg",
        soil: "Alluvial / Clayey",
        temp: "25°C - 30°C",
        rain: "100cm - 200cm",
        region: "West Bengal, Punjab, Uttar Pradesh, Andhra Pradesh",
        harvest: "Kharif (June - October)",
        description: "Rice is a tropical crop that requires high temperature, high humidity, and abundant rainfall. It is grown extensively in flood plains and deltaic regions where water retention is high. Continuous standing water is essential for several weeks after transplanting. It is the primary staple food for a large part of the world population, especially in East and South Asia."
    },
    {
        id: 2,
        name: "Wheat",
        summary: "The golden grain of temperate climates, essential for global food security.",
        image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        soil: "Well-drained Loamy",
        temp: "10°C - 25°C",
        rain: "50cm - 75cm",
        region: "Punjab, Haryana, Madhya Pradesh, Rajasthan",
        harvest: "Rabi (November - April)",
        description: "Wheat is a temperate crop that requires a cool growing season and bright sunshine at the time of ripening. It grows best in well-drained loamy soils. It is the second most important cereal crop in India and a primary food source for many Northern and Central Indian states. Irrigation is vital for its growth in areas with lower rainfall."
    },
    {
        id: 3,
        name: "Maize",
        summary: "A versatile crop used as food, fodder, and industrial raw material.",
        image: "https://images.unsplash.com/photo-1551754655-cd27e38d2076?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        soil: "Old Alluvial",
        temp: "21°C - 27°C",
        rain: "50cm - 100cm",
        region: "Karnataka, Madhya Pradesh, Bihar, Andhra Pradesh",
        harvest: "Kharif / Rabi",
        description: "Maize is a crop which is used both as food and fodder. It is a Kharif crop but in states like Bihar it is grown in Rabi season also. It grows well in old alluvial soil. Use of modern inputs such as HYV seeds, fertilizers and irrigation have contributed to the increasing production of maize."
    },
    {
        id: 4,
        name: "Cotton",
        summary: "Known as 'White Gold', it is the backbone of the textile industry.",
        image: "https://media.gettyimages.com/id/157433082/photo/cotton-crop-detail.jpg?s=612x612&w=0&k=20&c=WBRO6a92V1LF2U5szWLuT0r1rcNk1c5vVN2JePJACGI=",
        soil: "Black Soil (Regur)",
        temp: "21°C - 30°C",
        rain: "50cm - 100cm",
        region: "Maharashtra, Gujarat, Telangana, Haryana",
        harvest: "Kharif (6-8 months)",
        description: "Cotton is a tropical and subtropical crop. It requires 210 frost-free days and bright sunshine for its growth. It is a 'dry' crop and requires less water compared to rice. Black soil of the Deccan plateau is ideal for its cultivation. India is one of the largest producers of cotton globally."
    },
    {
        id: 5,
        name: "Sugarcane",
        summary: "A tall perennial grass used for sugar, ethanol, and jaggery production.",
        image: "https://media.istockphoto.com/id/179680007/photo/sugar-cane.jpg?s=612x612&w=0&k=20&c=2wJV8ZlHvctpXOcvoaeBkIE4ACO7HJ6nzz_ADZpiN2g=",
        soil: "Loamy / Alluvial",
        temp: "21°C - 27°C",
        rain: "75cm - 100cm",
        region: "Uttar Pradesh, Maharashtra, Karnataka, Tamil Nadu",
        harvest: "Annual (10-12 months)",
        description: "Sugarcane is a tropical as well as a subtropical crop. It grows well in hot and humid climates. It can be grown on a variety of soils and needs manual labour from sowing to harvesting. It is the main source of sugar, gur (jaggery), khandsari and molasses."
    },
    {
        id: 6,
        name: "Tea",
        summary: "An intensive plantation crop requiring specific hilly terrains.",
        image: "https://media.istockphoto.com/id/181134564/photo/tea-crop.jpg?s=612x612&w=0&k=20&c=x9muhj7wuZv8BG0qe7cGGbtsb9H391rUqh7Y3OSHDhs=",
        soil: "Deep Fertile Loamy",
        temp: "13°C - 35°C",
        rain: "150cm - 250cm",
        region: "Assam, West Bengal, Kerala, Tamil Nadu",
        harvest: "Continuous",
        description: "Tea cultivation is an example of plantation agriculture. It is an important beverage crop. The tea plant grows well in tropical and subtropical climates endowed with deep and fertile well-drained soil, rich in humus and organic matter. Tea bushes require warm and moist frost-free climate all through the year. Frequent showers evenly distributed over the year ensure continuous growth of tender leaves."
    },
    {
        id: 7,
        name: "Coffee",
        summary: "A high-value plantation crop cherished for its aromatic beans.",
        image: "https://media.gettyimages.com/photos/coffee-berries-closeup-arabica-coffee-berries-with-agriculturist-picture-id1178874080?k=20&m=1178874080&s=612x612&w=0&h=1gTxFLsKla27o6Z2IvM7CHcwl-gBMBsX8x1uWOsDtGI=",
        soil: "Well-drained Forest Soil",
        temp: "15°C - 28°C",
        rain: "150cm - 250cm",
        region: "Karnataka, Kerala, Tamil Nadu",
        harvest: "Winter",
        description: "Indian coffee is known in the world for its good quality. The Arabica variety initially brought from Yemen is produced in the country. Initially its cultivation was introduced on the Baba Budan Hills and even today its cultivation is confined to the Nilgiri in Karnataka, Kerala and Tamil Nadu."
    },
    
    {
        id: 8,
        name: "Jute",
        summary: "A natural fiber crop also known as the 'Golden Fibre' of India.",
        image: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a1/Jute_field.jpg/800px-Jute_field.jpg",
        soil: "Alluvial / Loamy",
        temp: "24°C - 37°C",
        rain: "150cm - 250cm",
        region: "West Bengal, Bihar, Assam, Odisha",
        harvest: "Kharif (March - July)",
        description: "Jute is known as the golden fibre. It grows well in the hot and humid climate of eastern India. It requires well-drained fertile soils in the flood plains where alluvial soil is renewed every year. It is used to make bags, ropes, carpets and other products. India is one of the largest producers of jute globally."
    },
    {
        id: 9,
        name: "Rubber",
        summary: "A tropical plantation crop essential for industrial and commercial use.",
        image: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/45/Latex_draining_into_cup.JPG/800px-Latex_draining_into_cup.JPG",
        soil: "Laterite Soil",
        temp: "25°C - 35°C",
        rain: "200cm+",
        region: "Kerala, Tamil Nadu, Karnataka, Tripura",
        harvest: "Continuous (Tapping)",
        description: "Rubber is an important industrial raw material. It is an equatorial crop, but under special conditions it is also grown in tropical and sub-tropical areas. It requires moist and humid climates with rainfall of more than 200 cm. It is mainly grown in Kerala, Tamil Nadu, Karnataka and Andaman and Nicobar Islands. India is the fourth largest producer of natural rubber."
    },
    {
        id: 10,
        name: "Pulses",
        summary: "Protein-rich leguminous crops essential for Indian diet and soil health.",
        image: "https://images.unsplash.com/photo-1515543904425-705de85b22ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        soil: "Sandy Loam / Loamy",
        temp: "20°C - 27°C",
        rain: "25cm - 60cm",
        region: "Madhya Pradesh, Maharashtra, Rajasthan, Uttar Pradesh",
        harvest: "Rabi / Kharif",
        description: "Pulses include a variety of crops like gram, moong, masoor, arhar, and urad. They are a major source of protein in the Indian vegetarian diet. Being leguminous crops, they help restore soil fertility by fixing nitrogen from the air. India is the largest producer and consumer of pulses in the world."
    },
    {
        id: 11,
        name: "Soybean",
        summary: "A versatile oilseed crop rich in protein and essential fatty acids.",
        image: "https://images.unsplash.com/photo-1599709606362-e06ca68f4282?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        soil: "Black Soil / Loamy",
        temp: "20°C - 30°C",
        rain: "60cm - 100cm",
        region: "Madhya Pradesh, Maharashtra, Rajasthan, Karnataka",
        harvest: "Kharif (June - October)",
        description: "Soybean is a major oilseed crop that is also a rich source of plant protein. It is used for making oil, animal feed, and various food products like tofu and soya milk. Madhya Pradesh is the largest producer, often called the Soy State of India. Soybean crops improve soil fertility as they fix atmospheric nitrogen."
    },
    {
        id: 12,
        name: "Mustard",
        summary: "A major Rabi oilseed crop important for cooking oil production.",
        image: "https://images.unsplash.com/photo-1594731884638-8197c3102d1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        soil: "Sandy Loam / Alluvial",
        temp: "10°C - 25°C",
        rain: "25cm - 40cm",
        region: "Rajasthan, Uttar Pradesh, Haryana, Madhya Pradesh",
        harvest: "Rabi (October - March)",
        description: "Mustard is one of the most important Rabi oilseed crops in India. The oil extracted from mustard seeds is widely used for cooking in North India. It requires a cool climate for its growth and a warm climate during its maturity. Rajasthan is the leading producer state. The crop grows well in drained loamy soils."
    },
    {
        id: 13,
        name: "Onion",
        summary: "A high-value vegetable crop with year-round demand across India.",
        image: "https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        soil: "Well-drained Sandy Loam",
        temp: "13°C - 24°C",
        rain: "50cm - 75cm",
        region: "Maharashtra, Karnataka, Madhya Pradesh, Rajasthan",
        harvest: "Rabi / Kharif / Late Kharif",
        description: "Onion is one of the most important commercial vegetable crops in India. It is grown in almost all states and is a key ingredient in Indian cuisine. Maharashtra (Nashik) is the largest producer and exporter. Onion market prices are highly volatile and significantly impact India's food inflation. The crop requires well-drained soils and proper irrigation."
    }
];

const cropRequirements = {
    "Rice": { n: 110, p: 50, k: 50, phMin: 5.5, phMax: 6.5 },
    "Wheat": { n: 135, p: 60, k: 45, phMin: 6.0, phMax: 7.5 },
    "Maize": { n: 165, p: 70, k: 50, phMin: 5.8, phMax: 7.0 },
    "Cotton": { n: 90, p: 45, k: 35, phMin: 6.0, phMax: 8.0 },
    "Sugarcane": { n: 275, p: 110, k: 110, phMin: 6.5, phMax: 7.5 },
    "Tea": { n: 125, p: 45, k: 65, phMin: 4.5, phMax: 5.5 },
    "Coffee": { n: 130, p: 65, k: 125, phMin: 5.5, phMax: 6.5 },
    "Jute": { n: 50, p: 25, k: 25, phMin: 5.0, phMax: 7.0 },
    "Rubber": { n: 35, p: 35, k: 18, phMin: 4.5, phMax: 6.0 },
    "Pulses": { n: 22, p: 50, k: 25, phMin: 6.0, phMax: 7.5 },
    "Soybean": { n: 25, p: 70, k: 50, phMin: 6.0, phMax: 7.0 },
    "Mustard": { n: 80, p: 40, k: 40, phMin: 6.0, phMax: 7.5 },
    "Onion": { n: 100, p: 50, k: 80, phMin: 6.0, phMax: 7.0 }
};

// DOM Elements
const cropGrid = document.getElementById('cropGrid');
const cropSearch = document.getElementById('cropSearch');
const modal = document.getElementById('cropModal');
const modalBody = document.getElementById('modalBody');
const closeModal = document.querySelector('.close-modal');
const targetCropSelect = document.getElementById('targetCrop');
const soilForm = document.getElementById('soilForm');
const analysisResult = document.getElementById('analysisResult');
const resultOutput = document.getElementById('resultOutput');
const resultStatus = document.getElementById('resultStatus');
const resultActions = document.getElementById('resultActions');
const saveReportBtn = document.getElementById('saveReportBtn');
const savedReportsHistory = document.getElementById('savedReportsHistory');
const reportsGrid = document.getElementById('reportsGrid');
const clearHistoryBtn = document.getElementById('clearHistoryBtn');
const whatsappForm = document.getElementById('whatsappForm');
const getWeatherBtn = document.getElementById('getWeatherBtn');
const detectLocationBtn = document.getElementById('detectLocationBtn');
const farmLocationInput = document.getElementById('farmLocation');
const aiRecommendationContent = document.getElementById('aiRecommendationContent');
const getAiAdviceBtn = document.getElementById('getAiAdviceBtn');
const marketBody = document.getElementById('marketBody');
const mpDistrictSelect = document.getElementById('mpDistrict');
const mpMandiSelect = document.getElementById('mpMandi');
const filterMarketBtn = document.getElementById('filterMarketBtn');
const schemesGrid = document.getElementById('schemesGrid');
const pestImageInput = document.getElementById('pestImageInput');
const selectImageBtn = document.getElementById('selectImageBtn');
const pestPreviewArea = document.getElementById('pestPreviewArea');
const pestUploadArea = document.getElementById('pestUploadArea');
const pestPreviewImg = document.getElementById('pestPreviewImg');
const analyzePestBtn = document.getElementById('analyzePestBtn');
const pestResultPanel = document.getElementById('pestResultPanel');
const scanLine = document.getElementById('scanLine');
const reuploadBtn = document.getElementById('reuploadBtn');
const droneBookingForm = document.getElementById('droneBookingForm');
const farmAcreageInput = document.getElementById('farmAcreage');
const droneCropTypeSelect = document.getElementById('droneCropType');
const estCostDisplay = document.getElementById('estCost');

let currentAnalysis = null;
let currentWeatherData = null;

// Populate Crop Select
function populateCropSelect() {
    if (!targetCropSelect) return;
    
    // Clear existing (except first)
    targetCropSelect.innerHTML = '<option value="" disabled selected>Select Crop</option>';
    
    crops.forEach(crop => {
        const option = document.createElement('option');
        option.value = crop.name;
        option.textContent = crop.name;
        targetCropSelect.appendChild(option);
    });
    
    // Add "Other" option
    const otherOpt = document.createElement('option');
    otherOpt.value = "Other";
    otherOpt.textContent = "Other (Specify name)";
    targetCropSelect.appendChild(otherOpt);
}

// Toggle "Other Crop" input field
if (targetCropSelect) {
    targetCropSelect.addEventListener('change', (e) => {
        const otherGroup = document.getElementById('otherCropGroup');
        if (e.target.value === "Other") {
            otherGroup.classList.remove('hidden');
            document.getElementById('otherCropName').required = true;
        } else {
            otherGroup.classList.add('hidden');
            document.getElementById('otherCropName').required = false;
        }
    });
}

// Initial Render with Animation
function renderCrops(cropList) {
    if (!cropGrid) return;
    cropGrid.innerHTML = '';

    if (cropList.length === 0) {
        cropGrid.innerHTML = '<div class="no-results" style="grid-column: 1/-1; padding: 40px; color: var(--text-muted);">No crops found matching your search.</div>';
        return;
    }

    cropList.forEach((crop, index) => {
        const card = document.createElement('div');
        card.className = 'crop-card reveal-card';
        card.style.animationDelay = `${index * 0.08}s`; // Slightly slower for elegance
        card.innerHTML = `
            <div class="crop-img" style="background-image: url('${crop.image}')">
                <div class="crop-img-overlay">${crop.name}</div>
            </div>
            <div class="crop-info">
                <h3 class="crop-name">${crop.name}</h3>
                <p class="crop-summary">${crop.summary}</p>
                <div class="crop-stats-brief">
                    <div class="stat-bubble" title="Ideal Temperature"><i class="fa-solid fa-temperature-half"></i> ${crop.temp}</div>
                    <div class="stat-bubble" title="Required Rainfall"><i class="fa-solid fa-droplet"></i> ${crop.rain}</div>
                    <div class="stat-bubble" title="Harvest Season"><i class="fa-solid fa-calendar-check"></i> ${crop.harvest.split('(')[0]}</div>
                </div>
                <button class="btn-card">View Full Advisory</button>
            </div>
        `;
        card.addEventListener('click', () => openCropDetails(crop.id));
        cropGrid.appendChild(card);
    });
}

// Trigger Advisory when scrolled into view
function initAdvisoryScrollReveal() {
    const advisorySection = document.getElementById('advisory');
    if (!advisorySection) return;

    let hasRendered = false;
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && !hasRendered) {
                hasRendered = true;
                renderCrops(crops);
                observer.unobserve(advisorySection);
            }
        });
    }, { threshold: 0.1 });

    observer.observe(advisorySection);
}

// Open Modal with Details
function openCropDetails(id) {
    const crop = crops.find(c => c.id === id);
    if (!crop) return;

    modalBody.innerHTML = `
        <div class="modal-header-info">
            <div class="modal-img" style="background-image: url('${crop.image}')"></div>
            <div class="modal-details">
                <h2>${crop.name}</h2>
                <p class="crop-summary" style="margin-bottom: 20px; font-size: 1.1rem;">${crop.summary}</p>
                
                <div class="detail-grid">
                    <div class="detail-item">
                        <h4>Ideal Soil</h4>
                        <p>${crop.soil}</p>
                    </div>
                    <div class="detail-item">
                        <h4>Temperature</h4>
                        <p>${crop.temp}</p>
                    </div>
                    <div class="detail-item">
                        <h4>Annual Rainfall</h4>
                        <p>${crop.rain}</p>
                    </div>
                    <div class="detail-item">
                        <h4>Major Regions</h4>
                        <p>${crop.region}</p>
                    </div>
                    <div class="detail-item">
                        <h4>Harvesting Season</h4>
                        <p>${crop.harvest}</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="full-description">
            <h3>Cultivation Guide & Advisory</h3>
            <p>${crop.description}</p>
        </div>
    `;

    modal.style.display = 'block';
    document.body.style.overflow = 'hidden'; // Prevent scroll
}

// Close Modal
closeModal.onclick = () => {
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
};

window.onclick = (event) => {
    if (event.target == modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
};

// Search Logic
cropSearch.addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase().trim();
    
    if (searchTerm === "") {
        renderCrops(crops);
        return;
    }

    const filteredCrops = crops.filter(crop =>
        crop.name.toLowerCase().includes(searchTerm) ||
        crop.summary.toLowerCase().includes(searchTerm)
    );
    renderCrops(filteredCrops);
});

// Soil Analysis Logic
soilForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    let cropName = targetCropSelect.value;
    let req = cropRequirements[cropName];
    
    // Handle "Other" crop
    if (cropName === "Other") {
        cropName = document.getElementById('otherCropName').value;
        // Use general balanced NPK requirements for unknown crops
        req = { n: 120, p: 60, k: 40, phMin: 6.0, phMax: 7.0 };
    }

    if (!req) return;

    const n = parseFloat(document.getElementById('nitrogen').value);
    const p = parseFloat(document.getElementById('phosphorus').value);
    const k = parseFloat(document.getElementById('potassium').value);
    const ph = parseFloat(document.getElementById('ph').value);

    // Try backend first, then fall back to local analysis
    const backendResult = await callSoilBackend({ crop: cropName, n, p, k, ph });

    if (backendResult && backendResult.recommendations) {
        // Use backend results
        const recs = backendResult.recommendations.map(r => ({
            nutrient: r.nutrient,
            status: r.status,
            advice: r.advice
        }));
        displayResults(cropName, recs, backendResult.isDeficient, { n, p, k, ph });
    } else {
        // Local fallback analysis
        let recommendations = [];
        let isDeficient = false;

        // Nitrogen Analysis
        if (n < req.n) {
            recommendations.push({
                nutrient: "Nitrogen (N)",
                status: "Low",
                advice: `Add approx. <span>${((req.n - n) * 2.17).toFixed(1)} kg/ha of Urea</span> to meet requirements.`
            });
            isDeficient = true;
        }

        // Phosphorus Analysis
        if (p < req.p) {
            recommendations.push({
                nutrient: "Phosphorus (P)",
                status: "Low",
                advice: `Apply <span>${((req.p - p) * 2.17).toFixed(1)} kg/ha of DAP</span> or <span>${((req.p - p) * 6.25).toFixed(1)} kg/ha of SSP</span>.`
            });
            isDeficient = true;
        }

        // Potassium Analysis
        if (k < req.k) {
            recommendations.push({
                nutrient: "Potassium (K)",
                status: "Low",
                advice: `Apply <span>${((req.k - k) * 1.67).toFixed(1)} kg/ha of MOP (Muriate of Potash)</span>.`
            });
            isDeficient = true;
        }

        // pH Analysis
        if (ph < req.phMin) {
            recommendations.push({
                nutrient: "Soil pH",
                status: "Acidic",
                advice: `Soil is too acidic for ${cropName}. Apply <span>Agricultural Lime</span> to increase pH.`
            });
            isDeficient = true;
        } else if (ph > req.phMax) {
            recommendations.push({
                nutrient: "Soil pH",
                status: "Alkaline",
                advice: `Soil is too alkaline for ${cropName}. Apply <span>Gypsum</span> or sulfur to lower pH.`
            });
            isDeficient = true;
        }

        displayResults(cropName, recommendations, isDeficient, { n, p, k, ph });
    }
});

// Logic to bypass local soil analysis if backend is active
async function callSoilBackend(params) {
    try {
        const response = await fetch(`${BACKEND_URL}/analyze-soil`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(params)
        });
        return await response.json();
    } catch (e) {
        return null;
    }
}

function displayResults(cropName, recs, isDeficient, params) {
    analysisResult.classList.remove('hidden');
    resultActions.classList.remove('hidden');
    resultOutput.innerHTML = `<h4>Recommendations for ${cropName}:</h4>`;

    currentAnalysis = {
        crop: cropName,
        params: params,
        recommendations: recs,
        date: new Date().toLocaleString(),
        id: Date.now()
    };

    if (!isDeficient) {
        resultStatus.textContent = "Optimal Soil Health";
        resultStatus.className = "result-status status-optimal";
        resultOutput.innerHTML += `<p>Your soil parameters are excellent for growing ${cropName}. No major chemical additions required.</p>`;
    } else {
        resultStatus.textContent = "Action Required";
        resultStatus.className = "result-status status-deficient";

        recs.forEach(rec => {
            resultOutput.innerHTML += `
                <div class="rec-item">
                    <h5>${rec.nutrient} - ${rec.status}</h5>
                    <p>${rec.advice}</p>
                </div>
            `;
        });
    }

    // Scroll to results
    analysisResult.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// Saving & History Logic
saveReportBtn.addEventListener('click', () => {
    if (!currentAnalysis) return;

    let reports = JSON.parse(localStorage.getItem('agrotech_reports') || '[]');
    reports.unshift(currentAnalysis); // Add to front
    localStorage.setItem('agrotech_reports', JSON.stringify(reports));

    saveReportBtn.innerHTML = '<i class="fa-solid fa-check"></i> Saved!';
    saveReportBtn.disabled = true;

    setTimeout(() => {
        saveReportBtn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Save Report';
        saveReportBtn.disabled = false;
    }, 2000);

    renderHistory();
});

function renderHistory() {
    const reports = JSON.parse(localStorage.getItem('agrotech_reports') || '[]');

    if (reports.length === 0) {
        savedReportsHistory.classList.add('hidden');
        return;
    }

    savedReportsHistory.classList.remove('hidden');
    reportsGrid.innerHTML = '';

    reports.forEach(report => {
        const card = document.createElement('div');
        card.className = 'history-card';
        card.innerHTML = `
            <button class="btn-remove" onclick="removeReport(${report.id})"><i class="fa-solid fa-trash-can"></i></button>
            <span class="date">${report.date}</span>
            <span class="crop">${report.crop}</span>
            <div class="parameters">
                <span class="param-badge">N: ${report.params.n}</span>
                <span class="param-badge">P: ${report.params.p}</span>
                <span class="param-badge">K: ${report.params.k}</span>
                <span class="param-badge">pH: ${report.params.ph}</span>
            </div>
            <button class="btn-card" style="padding: 5px 15px; font-size: 0.75rem;" onclick="viewSavedReport(${report.id})">View Analysis</button>
        `;
        reportsGrid.appendChild(card);
    });
}

window.removeReport = (id) => {
    let reports = JSON.parse(localStorage.getItem('agrotech_reports') || '[]');
    reports = reports.filter(r => r.id !== id);
    localStorage.setItem('agrotech_reports', JSON.stringify(reports));
    renderHistory();
};

window.viewSavedReport = (id) => {
    let reports = JSON.parse(localStorage.getItem('agrotech_reports') || '[]');
    const report = reports.find(r => r.id === id);
    if (report) {
        displayResults(report.crop, report.recommendations, report.recommendations.length > 0, report.params);
    }
};

clearHistoryBtn.addEventListener('click', () => {
    if (confirm('Are you sure you want to clear all saved reports?')) {
        localStorage.removeItem('agrotech_reports');
        renderHistory();
    }
});

// Weather Logic
const mockWeatherData = {
    "Delhi": { temp: "32°C", desc: "Sunny", humidity: "30%", wind: "15 km/h", rain: "5%", icon: "fa-solid fa-sun" },
    "Mumbai": { temp: "29°C", desc: "Humid", humidity: "85%", wind: "20 km/h", rain: "40%", icon: "fa-solid fa-cloud-showers-heavy" },
    "Bangalore": { temp: "24°C", desc: "Pleasant", humidity: "50%", wind: "10 km/h", rain: "15%", icon: "fa-solid fa-cloud-sun" },
    "Lucknow": { temp: "35°C", desc: "Hot & Dry", humidity: "20%", wind: "18 km/h", rain: "0%", icon: "fa-solid fa-sun" },
    "Chandigarh": { temp: "30°C", desc: "Haze", humidity: "40%", wind: "10 km/h", rain: "2%", icon: "fa-solid fa-smog" },
    "Patna": { temp: "33°C", desc: "Very Hot", humidity: "35%", wind: "14 km/h", rain: "0%", icon: "fa-solid fa-sun" },
    "Jaipur": { temp: "38°C", desc: "Extreme Heat", humidity: "15%", wind: "25 km/h", rain: "0%", icon: "fa-solid fa-sun" },
    "Chennai": { temp: "31°C", desc: "High Humidity", humidity: "75%", wind: "22 km/h", rain: "10%", icon: "fa-solid fa-cloud" },
    "Kolkata": { temp: "30°C", desc: "Overcast", humidity: "80%", wind: "12 km/h", rain: "60%", icon: "fa-solid fa-cloud-rain" },
    "default": { temp: "27°C", desc: "Clear Sky", humidity: "45%", wind: "12 km/h", rain: "10%", icon: "fa-solid fa-cloud-sun" }
};

function updateWeather(city) {
    const data = mockWeatherData[city] || mockWeatherData["default"];
    currentWeatherData = data;
    
    // Update Farmer UI
    document.getElementById('currentCity').textContent = `${city || 'Your Farm'}, IN`;
    document.getElementById('mainTemp').textContent = data.temp;
    document.getElementById('weatherDesc').textContent = data.desc;
    document.getElementById('humidity').textContent = data.humidity;
    document.getElementById('windSpeed').textContent = data.wind;
    document.getElementById('rainChance').textContent = data.rain;
    document.getElementById('mainWeatherIcon').className = data.icon;

    // Update Admin UI
    updateAdminWeatherDisplay(data);
}

function updateAdminWeatherDisplay(data) {
    if (!data) data = currentWeatherData || mockWeatherData["default"];
    
    const adminTemp = document.getElementById('adminTemp');
    const adminDesc = document.getElementById('adminDesc');
    const adminIcon = document.getElementById('adminWeatherIcon');
    const adminAiAdvice = document.getElementById('adminAiAdvice');
    
    if (adminTemp) adminTemp.textContent = data.temp;
    if (adminDesc) adminDesc.textContent = data.desc;
    if (adminIcon) adminIcon.className = data.icon;
    
    // Copy current AI advice to admin if it exists
    if (adminAiAdvice && aiRecommendationContent) {
        if (!aiRecommendationContent.innerHTML.includes("Waiting")) {
            adminAiAdvice.innerHTML = aiRecommendationContent.innerHTML;
        } else {
            adminAiAdvice.innerHTML = `<p style="font-size: 0.85rem;">Waiting for AI Analysis on main dashboard...</p>`;
        }
    }
}

getAiAdviceBtn.addEventListener('click', () => {
    if (!currentWeatherData) {
        alert("Please sync or detect your location first to get weather data.");
        return;
    }

    getAiAdviceBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Analyzing...';

    setTimeout(() => {
        const temp = parseInt(currentWeatherData.temp);
        const month = new Date().getMonth() + 1; // 1-12
        let bestCrop = null;
        let season = "";

        // Determine Season
        if (month >= 6 && month <= 10) season = "Kharif";
        else if (month >= 11 || month <= 3) season = "Rabi";
        else season = "Zaid (Summer)";

        // AI Logic: Matching temp and season to crops
        if (season === "Kharif") {
            if (temp > 25) bestCrop = crops.find(c => c.name === "Rice");
            else bestCrop = crops.find(c => c.name === "Maize");
        } else if (season === "Rabi") {
            if (temp < 20) bestCrop = crops.find(c => c.name === "Wheat");
            else bestCrop = crops.find(c => c.name === "Pulses");
        } else {
            bestCrop = temp > 30
                ? crops.find(c => c.name === "Cotton")
                : crops.find(c => c.name === "Sugarcane");
        }

        // Refine based on specific conditions if available
        if (currentWeatherData.desc.includes("Rain") && season === "Kharif") {
            bestCrop = crops.find(c => c.name === "Rice");
        }

        if (bestCrop) {
            const adviceHtml = `
                <span class="ai-description">Current Season: <strong>${season}</strong></span>
                <span class="ai-crop-badge">${bestCrop.name}</span>
                <p class="ai-description">Based on the temperature of <strong>${currentWeatherData.temp}</strong> and the <strong>${season}</strong> season, ${bestCrop.name} is the most suitable crop for your farm right now.</p>
            `;
            aiRecommendationContent.innerHTML = adviceHtml;
            // Update Admin AI Advice too
            const adminAiAdvice = document.getElementById('adminAiAdvice');
            if (adminAiAdvice) adminAiAdvice.innerHTML = adviceHtml;
        } else {
            const noAdviceHtml = `<p class="ai-description">Conditions are unique. We recommend consulting a specialist for today's forecast.</p>`;
            aiRecommendationContent.innerHTML = noAdviceHtml;
            const adminAiAdvice = document.getElementById('adminAiAdvice');
            if (adminAiAdvice) adminAiAdvice.innerHTML = noAdviceHtml;
        }

        getAiAdviceBtn.innerHTML = 'Analyze Best Crop';
    }, 1500);
});

if (getWeatherBtn) {
    getWeatherBtn.addEventListener('click', () => {
        const city = farmLocationInput ? farmLocationInput.value.trim() : "";
        if (city) {
            updateWeather(city);
        }
    });
}

// Detect Location via Geolocation API
if (detectLocationBtn) {
    detectLocationBtn.addEventListener('click', () => {
        if ("geolocation" in navigator) {
            detectLocationBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';

            navigator.geolocation.getCurrentPosition(async (position) => {
                const { latitude, longitude } = position.coords;
                try {
                    // Using a free reverse geocoding API to get the city name from coordinates
                    const response = await fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=en`);
                    const data = await response.json();
                    const city = data.city || data.locality || data.principalSubdivision;

                    if (farmLocationInput) farmLocationInput.value = city;
                    updateWeather(city);

                    detectLocationBtn.innerHTML = '<i class="fa-solid fa-location-crosshairs"></i>';
                    alert(`Location detected: ${city}. Updating weather...`);
                } catch (error) {
                    console.error("Reverse geocoding error:", error);
                    alert("Location detected, but couldn't fetch city name. Please enter manually.");
                    detectLocationBtn.innerHTML = '<i class="fa-solid fa-location-crosshairs"></i>';
                }
            }, (error) => {
                alert("Error: Location access denied or unavailable.");
                detectLocationBtn.innerHTML = '<i class="fa-solid fa-location-crosshairs"></i>';
            });
        } else {
            alert("Geolocation is not supported by your browser.");
        }
    });
}

// WhatsApp Alert Logic (Public)
if (whatsappForm) {
    whatsappForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const phone = document.getElementById('farmerPhone').value;
        const customMsg = document.getElementById('farmerMessage').value.trim();
        const location = farmLocationInput ? farmLocationInput.value : "";

        let message = `Namaste! I am interested in AgroTech WhatsApp Alerts. Please enable warnings and daily updates for my farm at ${location}.`;
        
        if (customMsg) {
            message += `\n\nAdditional Query: ${customMsg}`;
        }

        const whatsappUrl = `https://wa.me/${phone.replace(/\D/g, '')}?text=${encodeURIComponent(message)}`;

        alert('Redirecting to WhatsApp to confirm your subscription...');
        window.open(whatsappUrl, '_blank');
    });
}

function setCurrentDate() {
    const options = { weekday: 'long', day: 'numeric', month: 'long' };
    const dateStr = new Date().toLocaleDateString('en-US', options);
    const dateEl = document.getElementById('currentDate');
    if (dateEl) dateEl.textContent = dateStr;
}

// Automatic Location Trigger when section is visible
function initWeatherAutoDetection() {
    const weatherSection = document.getElementById('weather');
    if (!weatherSection) return;

    let hasObserved = false;
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && !hasObserved) {
                hasObserved = true;
                
                // Show a small premium hint
                const hint = document.createElement('div');
                hint.innerHTML = `<div style="position: fixed; top: 100px; right: 20px; background: var(--secondary); color: white; padding: 12px 20px; border-radius: 12px; z-index: 10000; box-shadow: 0 10px 30px rgba(0,0,0,0.2); animation: slideIn 0.5s ease-out;">
                    <i class="fa-solid fa-location-dot"></i> Auto-detecting your farm location...
                </div>`;
                document.body.appendChild(hint);
                setTimeout(() => hint.remove(), 4000);

                // Trigger location detection
                setTimeout(() => {
                    if (detectLocationBtn) {
                        detectLocationBtn.click();
                    }
                }, 500); // Shorter delay for "instant" feel
                
                observer.unobserve(weatherSection);
            }
        });
    }, { threshold: 0.1 }); // Lower threshold to trigger sooner

    observer.observe(weatherSection);
}

// Market Price Logic (Madhya Pradesh Focus)
const marketDataMP = {
    "Indore": {
        "Choithram Mandi": [
            { crop: "Soybean", min: 4200, max: 4800, avg: 4500, trend: "up" },
            { crop: "Wheat (Malwa)", min: 2400, max: 3100, avg: 2750, trend: "up" },
            { crop: "Cotton", min: 6200, max: 7800, avg: 7000, trend: "up" },
            { crop: "Potatoes", min: 900, max: 1300, avg: 1100, trend: "down" },
            { crop: "Tea", min: 14000, max: 22000, avg: 18000, trend: "stable" }
        ],
        "Laxmi Bai Nagar": [
            { crop: "Wheat", min: 2300, max: 2800, avg: 2550, trend: "stable" },
            { crop: "Maize", min: 1800, max: 2200, avg: 2000, trend: "up" },
            { crop: "Jute", min: 5800, max: 6800, avg: 6300, trend: "down" }
        ]
    },
    "Bhopal": {
        "Karond Mandi": [
            { crop: "Wheat", min: 2200, max: 2700, avg: 2450, trend: "up" },
            { crop: "Soybean", min: 4100, max: 4600, avg: 4350, trend: "down" },
            { crop: "Gram (Chana)", min: 5200, max: 6000, avg: 5600, trend: "up" },
            { crop: "Coffee", min: 32000, max: 48000, avg: 40000, trend: "up" }
        ],
        "Berasia Mandi": [
            { crop: "Maize", min: 1900, max: 2300, avg: 2100, trend: "up" },
            { crop: "Pulses", min: 6500, max: 8200, avg: 7350, trend: "up" },
            { crop: "Rubber", min: 15500, max: 19000, avg: 17250, trend: "stable" }
        ]
    },
    "Ujjain": {
        "Chimanganj Mandi": [
            { crop: "Soybean", min: 4300, max: 4900, avg: 4600, trend: "up" },
            { crop: "Sugarcane", min: 380, max: 450, avg: 415, trend: "stable" },
            { crop: "Wheat", min: 2400, max: 3000, avg: 2700, trend: "up" },
            { crop: "Green Gram (Moong)", min: 7000, max: 8500, avg: 7750, trend: "down" }
        ]
    },
    "Jabalpur": {
        "Krishi Upaj Mandi": [
            { crop: "Rice (Paddy)", min: 2100, max: 3000, avg: 2550, trend: "up" },
            { crop: "Peas", min: 3500, max: 5000, avg: 4250, trend: "up" },
            { crop: "Jute", min: 5500, max: 6500, avg: 6000, trend: "up" }
        ]
    },
    "Gwalior": {
        "Lashkar Mandi": [
            { crop: "Mustard (Sarson)", min: 5000, max: 5800, avg: 5400, trend: "down" },
            { crop: "Wheat", min: 2150, max: 2550, avg: 2350, trend: "up" },
            { crop: "Cotton", min: 6000, max: 7500, avg: 6750, trend: "stable" }
        ]
    },
    "Sagar": {
        "Sagar Mandi": [
            { crop: "Wheat", min: 2100, max: 2650, avg: 2375, trend: "up" },
            { crop: "Rice", min: 2800, max: 4000, avg: 3400, trend: "up" },
            { crop: "Pulses", min: 5300, max: 7200, avg: 6250, trend: "up" }
        ],
        "Bina Mandi": [
            { crop: "Wheat (Sharbati)", min: 3500, max: 5500, avg: 4500, trend: "up" },
            { crop: "Soybean", min: 4050, max: 4600, avg: 4325, trend: "down" },
            { crop: "Maize", min: 1850, max: 2150, avg: 2000, trend: "up" }
        ]
    }
};

function populateMarketFilters() {
    if (!mpDistrictSelect) return;

    // Populate Districts
    Object.keys(marketDataMP).forEach(dist => {
        const opt = document.createElement('option');
        opt.value = dist;
        opt.textContent = dist;
        mpDistrictSelect.appendChild(opt);
    });

    // Handle District Change
    mpDistrictSelect.addEventListener('change', (e) => {
        const district = e.target.value;
        mpMandiSelect.innerHTML = '<option value="">Select Mandi</option>';

        if (district) {
            mpMandiSelect.disabled = false;
            Object.keys(marketDataMP[district]).forEach(mandi => {
                const opt = document.createElement('option');
                opt.value = mandi;
                opt.textContent = mandi;
                mpMandiSelect.appendChild(opt);
            });
        } else {
            mpMandiSelect.disabled = true;
        }
    });

    // Get Prices Button
    filterMarketBtn.addEventListener('click', () => {
        const district = mpDistrictSelect.value;
        const mandi = mpMandiSelect.value;

        if (district && mandi) {
            renderMPPrices(district, mandi);
        } else {
            alert('Please select both District and Mandi');
        }
    });
}

function renderMPPrices(district, mandi) {
    if (!marketBody) return;
    const data = marketDataMP[district][mandi];
    marketBody.innerHTML = '';

    data.forEach(item => {
        const row = document.createElement('tr');
        const trendIcon = item.trend === 'up' ? 'fa-arrow-trend-up' : item.trend === 'down' ? 'fa-arrow-trend-down' : 'fa-minus';
        const trendClass = item.trend === 'up' ? 'trend-up' : item.trend === 'down' ? 'trend-down' : '';

        row.innerHTML = `
            <td>${item.crop}</td>
            <td>₹${item.min}</td>
            <td>₹${item.max}</td>
            <td>₹${item.avg}</td>
            <td><span class="trend-badge ${trendClass}"><i class="fa-solid ${trendIcon}"></i> ${item.trend.toUpperCase()}</span></td>
        `;
        marketBody.appendChild(row);
    });
}

// Government Schemes Data
const schemesData = [
    {
        title: "PM-Kisan Samman Nidhi",
        icon: "fa-solid fa-hand-holding-dollar",
        desc: "An income support scheme providing ₹6,000 per year to all landholding farmer families in three installments.",
        benefits: ["Direct Cash Support", "Financial Security"]
    },
    {
        title: "PM Fasal Bima Yojana",
        icon: "fa-solid fa-umbrella",
        desc: "A crop insurance scheme that protects farmers against yield losses due to natural calamities, pests, and diseases.",
        benefits: ["Low Premium", "Risk Coverage", "Loss Recovery"]
    },
    {
        title: "Kisan Credit Card (KCC)",
        icon: "fa-solid fa-credit-card",
        desc: "Provides farmers with timely credit for their cultivation and other needs like purchase of seeds, fertilizers, and pesticides.",
        benefits: ["Low Interest Loans", "Flexible Repayment"]
    },
    {
        title: "Soil Health Card Scheme",
        icon: "fa-solid fa-flask-vial",
        desc: "Provides soil health cards to farmers which carry crop-wise recommendations of nutrients and fertilizers required for individual farms.",
        benefits: ["Soil Analysis", "Fertilizer Tips", "Higher Yield"]
    },
    {
        title: "PM Krishi Sinchai Yojana",
        icon: "fa-solid fa-faucet-drip",
        desc: "Aimed at providing protective irrigation to all agricultural farms in the country to produce 'per drop more crop'.",
        benefits: ["Modern Irrigation", "Water Efficiency"]
    },
    {
        title: "Paramparagat Krishi Vikas",
        icon: "fa-solid fa-seedling",
        desc: "Promotes organic farming through a cluster approach and PGS (Participatory Guarantee System) certification.",
        benefits: ["Organic Growth", "Soil Health", "Sustainability"]
    },
    {
        title: "National Agriculture Market",
        icon: "fa-solid fa-globe",
        desc: "e-NAM is a pan-India electronic trading portal that networks the existing APMC mandis to create a unified national market.",
        benefits: ["Better Price Discovery", "No Middlemen"]
    },
    {
        title: "Livestock Insurance",
        icon: "fa-solid fa-cow",
        desc: "Provides protection against the death of livestock due to accidents, diseases, and other unforeseen events.",
        benefits: ["Animal Security", "Dairy Support", "Easy Claims"]
    }
];

function renderSchemes() {
    if (!schemesGrid) return;
    schemesGrid.innerHTML = '';

    schemesData.forEach(scheme => {
        const card = document.createElement('div');
        card.className = 'scheme-card';
        card.innerHTML = `
            <div class="scheme-icon"><i class="${scheme.icon}"></i></div>
            <h3>${scheme.title}</h3>
            <p>${scheme.desc}</p>
            <div class="scheme-benefits">
                ${scheme.benefits.map(b => `<span class="benefit-tag">${b}</span>`).join('')}
            </div>
            <button class="btn-scheme" onclick="window.open('https://www.google.com/search?q=${encodeURIComponent(scheme.title)}', '_blank')">Learn More</button>
        `;
        schemesGrid.appendChild(card);
    });
}

// Pest Diagnosis Logic
const diseaseData = [
    {
        name: "Yellow Rust (Puccinia striiformis)",
        info: "Yellow rust is a fungal disease that affects wheat. It appears as yellow-orange pustules in linear rows on the leaves, severely reducing grain size and quality.",
        severity: "High Risk",
        solutions: [
            "Apply Propiconazole 25% EC @ 500 ml/ha.",
            "Use rust-resistant wheat varieties for the next season.",
            "Avoid excessive use of Nitrogen fertilizers.",
            "Maintain distance if cultivating multiple crops."
        ]
    },
    {
        name: "Aphids (Aphis gossypii)",
        info: "Small, soft-bodied insects that suck the sap out of leaves, causing them to curl and turn yellow. They also secrete honeydew which leads to sooty mold.",
        severity: "Moderate",
        solutions: [
            "Spray Neem oil (5ml per liter of water).",
            "Introduce natural predators like ladybugs.",
            "Use yellow sticky traps to capture adult insects.",
            "Maintain high pressure water sprays to dislodge them."
        ]
    },
    {
        name: "Late Blight (Phytophthora infestans)",
        info: "A devastating disease of potato and tomato. It causes dark, water-soaked patches on leaves that can turn necrotic and spread rapidly in humid conditions.",
        severity: "Critical",
        solutions: [
            "Apply Mancozeb or Copper Oxychloride spray.",
            "Destroy infected plant debris immediately.",
            "Ensure proper spacing for air circulation.",
            "Monitor during cloudy/humid weather closely."
        ]
    }
];

selectImageBtn.addEventListener('click', () => pestImageInput.click());

pestImageInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
            pestPreviewImg.src = event.target.result;
            pestUploadArea.classList.add('hidden');
            pestPreviewArea.classList.remove('hidden');
        };
        reader.readAsDataURL(file);
    }
});

reuploadBtn.addEventListener('click', () => {
    pestUploadArea.classList.remove('hidden');
    pestPreviewArea.classList.add('hidden');
    pestResultPanel.classList.add('hidden');
    pestImageInput.value = '';
});

analyzePestBtn.addEventListener('click', () => {
    scanLine.style.display = 'block';
    analyzePestBtn.disabled = true;
    analyzePestBtn.innerHTML = '<i class="fa-solid fa-microchip fa-spin"></i> Analyzing...';

    setTimeout(async () => {
        scanLine.style.display = 'none';
        
        // Try Backend Diagnosis first
        try {
            const formData = new FormData();
            formData.append('file', pestImageInput.files[0]);
            const response = await fetch(`${BACKEND_URL}/diagnose-pest`, {
                method: 'POST',
                body: formData
            });
            const data = await response.json();
            
            document.getElementById('detectedDisease').textContent = data.detected;
            document.getElementById('diseaseInfo').textContent = data.info;
            document.getElementById('severityStatus').textContent = data.severity;
            
            const list = document.getElementById('solutionList');
            list.innerHTML = '';
            data.solutions.forEach(sol => {
                const li = document.createElement('li');
                li.textContent = sol;
                list.appendChild(li);
            });
            
        } catch (error) {
            // Local Fallback if backend fails
            const diagnosis = diseaseData[Math.floor(Math.random() * diseaseData.length)];
            document.getElementById('detectedDisease').textContent = diagnosis.name;
            document.getElementById('diseaseInfo').textContent = diagnosis.info;
            document.getElementById('severityStatus').textContent = diagnosis.severity;
            const list = document.getElementById('solutionList');
            list.innerHTML = '';
            diagnosis.solutions.forEach(sol => {
                const li = document.createElement('li');
                li.textContent = sol;
                list.appendChild(li);
            });
        }

        pestResultPanel.classList.remove('hidden');
        pestResultPanel.scrollIntoView({ behavior: 'smooth', block: 'center' });
        analyzePestBtn.innerHTML = 'Scan Complete';
        analyzePestBtn.disabled = false;
    }, 3000);
});

// Drone Service Logic
function populateDroneCrops() {
    if (!droneCropTypeSelect) return;
    crops.forEach(crop => {
        const opt = document.createElement('option');
        opt.value = crop.name;
        opt.textContent = crop.name;
        droneCropTypeSelect.appendChild(opt);
    });
}

if (farmAcreageInput) {
    farmAcreageInput.addEventListener('input', (e) => {
        const acres = parseFloat(e.target.value) || 0;
        const cost = acres * 500; // ₹500 per acre
        estCostDisplay.textContent = `₹${cost}`;
    });
}


// Initializing
initAdvisoryScrollReveal(); // Replaced direct call with scroll trigger
populateCropSelect();
renderHistory();
setCurrentDate();
populateMarketFilters();
renderSchemes();
populateDroneCrops();
initWeatherAutoDetection();

// Default View
setTimeout(() => {
    if (mpDistrictSelect) {
        mpDistrictSelect.value = "Indore";
        mpDistrictSelect.dispatchEvent(new Event('change'));
        setTimeout(() => {
            mpMandiSelect.value = "Choithram Mandi";
            renderMPPrices("Indore", "Choithram Mandi");
        }, 100);
    }
}, 500);

// Navbar scroll effect
window.addEventListener('scroll', () => {
    const header = document.querySelector('.header');
    if (window.scrollY > 50) {
        header.style.backgroundColor = 'rgba(255, 255, 255, 0.95)';
        header.style.boxShadow = '0 5px 20px rgba(0,0,0,0.1)';
    } else {
        header.style.backgroundColor = 'rgba(255, 255, 255, 0.7)';
        header.style.boxShadow = 'none';
    }
});




// Updated Drone Booking with LocalStorage persistence
if (droneBookingForm) {
    droneBookingForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('droneName').value;
        const mobile = document.getElementById('droneMobile').value;
        const acreage = farmAcreageInput.value;
        const date = document.getElementById('serviceDate').value;
        const crop = droneCropTypeSelect.value;

        const bookingData = { name, mobile, acreage, date, crop };
        
        // Save to LocalStorage for Admin
        const bookings = JSON.parse(localStorage.getItem('drone_bookings') || '[]');
        bookings.push(bookingData);
        localStorage.setItem('drone_bookings', JSON.stringify(bookings));

        alert(`✓ Drone Booking Requested!\n\nFarmer: ${name}\nMobile: ${mobile}\nArea: ${acreage} Acres\n\nOur pilot will contact you soon.`);
        droneBookingForm.reset();
        estCostDisplay.textContent = '₹0';
    });
}

// AI Chatbot Logic
const chatWindow = document.getElementById('chatWindow');
const chatMessages = document.getElementById('chatMessages');
const chatInputForm = document.getElementById('chatInputArea');
const userChatInput = document.getElementById('userChatMessage');

function toggleChat() {
    chatWindow.classList.toggle('hidden');
    if (!chatWindow.classList.contains('hidden')) {
        userChatInput.focus();
    }
}

if (chatInputForm) {
    chatInputForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const message = userChatInput.value.trim();
        if (!message) return;

        // Add User Message
        addChatMessage(message, 'user');
        userChatInput.value = '';

        // Simulate AI Response
        setTimeout(() => {
            const botResponse = getAgroBotResponse(message);
            addChatMessage(botResponse, 'bot');
        }, 1000);
    });
}

function addChatMessage(text, sender) {
    const msgDiv = document.createElement('div');
    msgDiv.className = `message ${sender}`;
    msgDiv.textContent = text;
    chatMessages.appendChild(msgDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function getAgroBotResponse(input) {
    const msg = input.toLowerCase();
    
    if (msg.includes('hello') || msg.includes('hi')) return "नमस्ते! I'm AgroBot. How can I help you today?";
    if (msg.includes('crop')) return "I can help with crop advisory! Which crop are you interested in? Wheat, Rice, and Cotton are popular ones right now.";
    if (msg.includes('soil')) return "For soil health, I recommend regular testing. Our 'Digital Soil Lab' above can help you with specific fertilizer amounts!";
    if (msg.includes('pest') || msg.includes('insect')) return "Oh, pests can be tricky. Try using our 'AI Pest Scanner' to upload a photo for instant identification.";
    if (msg.includes('drone')) return "Drone spraying is very efficient! You can book a slot in our 'Drone Sprayer' section.";
    if (msg.includes('mandi') || msg.includes('price')) return "You can check real-time mandi prices for Madhya Pradesh in our 'Live Market Access' section.";
    if (msg.includes('weather')) return "We have live weather monitoring! Check the 'Weather' card for current conditions in your city.";
    if (msg.includes('thank')) return "You're welcome! Happy farming! 🌾";
    
    return "That's interesting! I'm still learning, but you can find more details in our various sections like advisory, soil lab, and market prices.";
}
