from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import random

app = FastAPI(title="AgroTech AI Backend")

# Enable CORS for frontend communication
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Models ---
class SoilParameters(BaseModel):
    crop: str
    n: float
    p: float
    k: float
    ph: float

class Recommendation(BaseModel):
    nutrient: str
    status: str
    advice: str

# --- Mock Data ---
CROP_REQUIREMENTS = {
    "Rice": {"n": 110, "p": 50, "k": 50, "phMin": 5.5, "phMax": 6.5},
    "Wheat": {"n": 135, "p": 60, "k": 45, "phMin": 6.0, "phMax": 7.5},
    "Maize": {"n": 165, "p": 70, "k": 50, "phMin": 5.8, "phMax": 7.0},
    "Cotton": {"n": 90, "p": 45, "k": 35, "phMin": 6.0, "phMax": 8.0},
    "Sugarcane": {"n": 275, "p": 110, "k": 110, "phMin": 6.5, "phMax": 7.5},
    "Tea": {"n": 125, "p": 45, "k": 65, "phMin": 4.5, "phMax": 5.5},
    "Coffee": {"n": 130, "p": 65, "k": 125, "phMin": 5.5, "phMax": 6.5},
    "Jute": {"n": 50, "p": 25, "k": 25, "phMin": 5.0, "phMax": 7.0},
    "Rubber": {"n": 35, "p": 35, "k": 18, "phMin": 4.5, "phMax": 6.0},
    "Pulses": {"n": 22, "p": 50, "k": 25, "phMin": 6.0, "phMax": 7.5},
    "Soybean": {"n": 25, "p": 70, "k": 50, "phMin": 6.0, "phMax": 7.0},
    "Mustard": {"n": 80, "p": 40, "k": 40, "phMin": 6.0, "phMax": 7.5},
    "Onion": {"n": 100, "p": 50, "k": 80, "phMin": 6.0, "phMax": 7.0}
}

DISEASES = [
    {
        "name": "Yellow Rust (Puccinia striiformis)",
        "info": "Yellow rust is a fungal disease that affects wheat. It appears as yellow-orange pustules in linear rows on the leaves, severely reducing grain size and quality.",
        "severity": "High Risk",
        "solutions": ["Apply Propiconazole 25% EC @ 500 ml/ha.", "Use rust-resistant wheat varieties for the next season.", "Avoid excessive use of Nitrogen fertilizers.", "Maintain distance if cultivating multiple crops."]
    },
    {
        "name": "Aphids (Aphis gossypii)",
        "info": "Small, soft-bodied insects that suck the sap out of leaves, causing them to curl and turn yellow. They also secrete honeydew which leads to sooty mold.",
        "severity": "Moderate",
        "solutions": ["Spray Neem oil (5ml per liter of water).", "Introduce natural predators like ladybugs.", "Use yellow sticky traps to capture adult insects.", "Maintain high pressure water sprays to dislodge them."]
    },
    {
        "name": "Late Blight (Phytophthora infestans)",
        "info": "A devastating disease of potato and tomato. It causes dark, water-soaked patches on leaves that can turn necrotic and spread rapidly in humid conditions.",
        "severity": "Critical",
        "solutions": ["Apply Mancozeb or Copper Oxychloride spray.", "Destroy infected plant debris immediately.", "Ensure proper spacing for air circulation.", "Monitor during cloudy/humid weather closely."]
    }
]

# --- Endpoints ---

@app.get("/")
async def root():
    return {"message": "AgroTech API is running"}

@app.post("/analyze-soil")
async def analyze_soil(params: SoilParameters):
    req = CROP_REQUIREMENTS.get(params.crop)
    if not req:
        # Default requirements for unknown crops
        req = {"n": 120, "p": 60, "k": 40, "phMin": 6.0, "phMax": 7.0}
    
    recommendations = []
    
    # Nitrogen Analysis
    if params.n < req["n"]:
        urea = round((req["n"] - params.n) * 2.17, 1)
        recommendations.append(Recommendation(nutrient="Nitrogen (N)", status="Low", advice=f"Add approx. {urea} kg/ha of Urea to meet requirements."))
    
    # Phosphorus Analysis
    if params.p < req["p"]:
        dap = round((req["p"] - params.p) * 2.17, 1)
        ssp = round((req["p"] - params.p) * 6.25, 1)
        recommendations.append(Recommendation(nutrient="Phosphorus (P)", status="Low", advice=f"Apply {dap} kg/ha of DAP or {ssp} kg/ha of SSP."))
    
    # Potassium Analysis
    if params.k < req["k"]:
        mop = round((req["k"] - params.k) * 1.67, 1)
        recommendations.append(Recommendation(nutrient="Potassium (K)", status="Low", advice=f"Apply {mop} kg/ha of MOP (Muriate of Potash)."))
    
    # pH Analysis
    if params.ph < req["phMin"]:
        recommendations.append(Recommendation(nutrient="Soil pH", status="Acidic", advice=f"Soil is too acidic for {params.crop}. Apply Agricultural Lime to increase pH."))
    elif params.ph > req["phMax"]:
        recommendations.append(Recommendation(nutrient="Soil pH", status="Alkaline", advice=f"Soil is too alkaline for {params.crop}. Apply Gypsum or sulfur to lower pH."))

    return {
        "crop": params.crop,
        "isDeficient": len(recommendations) > 0,
        "recommendations": recommendations
    }

@app.post("/diagnose-pest")
async def diagnose_pest(file: UploadFile = File(...)):
    # This is where a real TensorFlow model would run:
    # model.predict(image)
    
    # Simulating a delay and processing
    diagnosis = random.choice(DISEASES)
    return {
        "detected": diagnosis["name"],
        "info": diagnosis["info"],
        "severity": diagnosis["severity"],
        "solutions": diagnosis["solutions"]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8005)
